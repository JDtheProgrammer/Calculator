class Constants {
  String get apiKey {
    return 'eb406aa82176a5062ac563b7';
  }

  String get exchangeRateapi {
    return 'https://v6.exchangerate-api.com/v6/eb406aa82176a5062ac563b7/pair/INR/USD/'; // AMOUNT
  }
}
